# mtt
Track your time with this simple tool (os independent, awesome!)

# User stories
- Start your workday: mtt start
- Make a break: mtt break
- Resume your work: mtt continue/mtt resume
- Stop your workday: mtt stop + "you worked $(hours) hours"
- If on a break and entering mtt break: "already on a break"
- If working and mtt continue/mtt resume: "
- Output your in/out times and total for the last 30 days (7 by default): mtt logs -d 30